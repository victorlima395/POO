package moto;

import veiculo.Veiculo;

public class Moto extends Veiculo{

    String guidao;
    String macaco;
    String manete;
    
    public void empinar(){
        System.out.println("Empinando!!! ... Raio.. Deu Ruim!");
    }

    /**
     * @return the guidao
     */
    public String getGuidao() {
        return guidao;
    }

    /**
     * @param guidao the guidao to set
     */
    public void setGuidao(String guidao) {
        this.guidao = guidao;
    }

    /**
     * @return the macaco
     */
    public String getMacaco() {
        return macaco;
    }

    /**
     * @param macaco the macaco to set
     */
    public void setMacaco(String macaco) {
        this.macaco = macaco;
    }

    /**
     * @return the manete
     */
    public String getManete() {
        return manete;
    }

    /**
     * @param manete the manete to set
     */
    public void setManete(String manete) {
        this.manete = manete;
    }

    
    
}
