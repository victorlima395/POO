/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package principal;

import objetos.Secretaria;

/**
 *
 * @author victo
 */
public class Principal {
    public static void main(String[] args) {
        Secretaria s1 = new Secretaria("Vitoria Lima", "078.626.863-81");
        s1.setLogin("victorialima395");
        s1.setDataContratação("10/02/2019");
        
        System.out.println("Atributos de Secretária");
        System.out.println("CPF: " + s1.getCpf());
        System.out.println("Nome: " + s1.getNome());
        System.out.println("Data de Contratação: " + s1.getDataContratação() + "\n");
    }
    
}
