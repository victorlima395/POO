/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetos;

/**
 *
 * @author victo
 */
public class Dono extends Gerente{
    
    public Dono(String nome, String CPF) {
        super(nome, CPF);
    }
    
    private String acessoGlobal;

   
    public String getAcessoGlobal() {
        return acessoGlobal;
    }

    public void setAcessoGlobal(String acessoGlobal) {
        this.acessoGlobal = acessoGlobal;
    }
    
}
