/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetos;

/**
 *
 * @author victo
 */
public class Funcionario extends Pessoa{
    
    private String dataContratacao;
    private double salario;
    
    public Funcionario(String nome, String CPF, String dataContratacao, double salario) {
        super(nome, CPF);
        this.dataContratacao = dataContratacao;
        this.salario = salario;
        
    }

    public String getDataContratacao() {
        return dataContratacao;
    }

    public void setDataContratacao(String dataContratacao) {
        this.dataContratacao = dataContratacao;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    

    
}
