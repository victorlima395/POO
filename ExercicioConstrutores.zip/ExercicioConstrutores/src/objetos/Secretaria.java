/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetos;

/**
 *
 * @author victo
 */
public class Secretaria extends Funcionario{
    
    public Secretaria(String nome, String CPF) {
        super(nome, CPF);
    }
    
    private String login;

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }
    
}
