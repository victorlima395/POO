
package atributoInstancia;

public class Casa {
    
    public String tamanho;
    public String qtdComodos;
    public boolean energiaEletrica;
    public String numero;
    public boolean garagem;
        
}
