
package atributoInstancia;

public class Smartphone {
    
    public String SO;
    public String processador;
    public String memRAM;
    public String tamanho;
    public String tipoTela;
    
}
