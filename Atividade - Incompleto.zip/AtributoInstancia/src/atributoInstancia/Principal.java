
package atributoInstancia;

public class Principal {
    
    public static void main(String[] args) {
        
        Casa casa = new Casa();
        Casa casa2 = new Casa();
        
        Pessoa pessoa = new Pessoa();
        Pessoa pessoa2 = new Pessoa();
        
        Reuniao reuniao = new Reuniao();
        Reuniao reuniao2 = new Reuniao();
        
        Smartphone smartphone = new Smartphone();
        Smartphone smartphone2 = new Smartphone();
        
    }
    
}
