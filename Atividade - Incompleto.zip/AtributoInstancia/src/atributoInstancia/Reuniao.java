
package atributoInstancia;

public class Reuniao {
    
    public String assunto;
    public String data;
    public String horario;
    public String local;
    public String qtdPessoas;
    
}
