
package atributoClasse;

public class Empresa {
    
    public static String qtdFuncionarios;
    public static String qtdSetores;
    public static String nacionalidade;
    public static String CNPJ;
    public static String tamanhoTotal;
    
}
