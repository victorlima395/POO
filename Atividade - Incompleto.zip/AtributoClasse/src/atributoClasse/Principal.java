
package atributoClasse;

public class Principal {
    
    public static void main(String[] args) {
        
        Carro carro = new Carro();
        Carro carro2 = new Carro();
        
        Empresa empresa = new Empresa();
        Empresa empresa2 = new Empresa();
        
        Moto moto = new Moto();
        Moto moto2 = new Moto();
        
        PlanetaTerra terra = new PlanetaTerra();
        PlanetaTerra terra2 = new PlanetaTerra(); 
        
    }
    
}
