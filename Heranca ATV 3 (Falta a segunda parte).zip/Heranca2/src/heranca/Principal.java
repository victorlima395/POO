/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package heranca;

/**
 *
 * @author victo
 */
public class Principal {

    public static void main(String[] args) {
        AlunoDeGraduacao al = new AlunoDeGraduacao();
        al.setCPF("078.626.863-81");
        al.setNome("Victor Lima");
        al.setInstituicao("Vaculdade Vale do Salgado");
        al.setMatricula("11200");
        al.setCurso("ADS");
        al.setDataNasc("01/05/2000");

        System.out.println("Atributos de Aluno de Graduação, que herda Aluno.\n");
        System.out.println("CPF: " + al.getCPF());
        System.out.println("Nome: " + al.getNome());
        System.out.println("Instituição: " + al.getInstituicao());
        System.out.println("Matrícula: " + al.getMatricula());
        System.out.println("Curso: " + al.getCurso());
        System.out.println("Data de Nascimento: " + al.getDataNasc() + "\n");

        System.out.println("Atributos de Faculdade, que herda Instituicao.\n");
        Faculdade f1 = new Faculdade();
        f1.setTipo("Ensino Superior");
        f1.setCNPJ("12309865535445789/56");
        f1.setMantenedora("TCC Educação, Ciência e Cultura");
        f1.setNome("Faculdade Vale do Salgado");
        f1.setEndereco("Avenida Monsenhor Frota");
        f1.setQtdAlunos("500");

        System.out.println("Tipo de Instituição: " + f1.getTipo());
        System.out.println("CNPJ: " + f1.getCNPJ());
        System.out.println("Mantenedora: " + f1.getMantenedora());
        System.out.println("Nome da Instituição: " + f1.getNome());
        System.out.println("Endereço: " + f1.getEndereco());
        System.out.println("Quantidade de Alunos: " + f1.getQtdAlunos() + "\n");

        System.out.println("Atributos de Aluno de Pós Graduação, que herda Aluno.\n");
        AlunoDePosGraduacao ap = new AlunoDePosGraduacao();
        ap.setCPF("078.626.863-81");
        ap.setNome("Victor Lima");
        ap.setInstituicao("Vaculdade Vale do Salgado");
        ap.setCargaHoraria("200h");
        ap.setTipo("Lato Sensu");
        ap.setCategoria("Especialização");

        System.out.println("CPF: " + ap.getCPF());
        System.out.println("Nome: " + ap.getNome());
        System.out.println("Instituição: " + ap.getInstituicao());
        System.out.println("Carga Horária: " + ap.getCargaHoraria());
        System.out.println("Tipo de Pós: " + ap.getTipo());
        System.out.println("Categoria: " + ap.getCategoria());

    }

}
