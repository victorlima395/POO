
package heranca;

public class Faculdade extends Instituicao{
    private String nome;
    private String CNPJ;
    private String qtdAlunos;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCNPJ() {
        return CNPJ;
    }

    public void setCNPJ(String CNPJ) {
        this.CNPJ = CNPJ;
    }

    public String getQtdAlunos() {
        return qtdAlunos;
    }

    public void setQtdAlunos(String qtdAlunos) {
        this.qtdAlunos = qtdAlunos;
    }
    
}
