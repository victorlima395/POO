
package main;

import objetos.Calculadora;
import objetos.Funcionario;
import objetos.Homem;

public class Principal {
    
    public static void main(String[] args) {
        
        Calculadora cal = new Calculadora();
        Funcionario fn = new Funcionario();
        Homem hm = new Homem();
        
                System.out.println("A soma é: "+cal.Somar(2, 2));
                System.out.println("A subtração é: "+cal.Subtrair(2, 2));
                System.out.println("A Divisão é: "+cal.Dividir(2, 2));
                System.out.println("A Multiplicação é: "+cal.Multiplicar(2, 2));

                System.out.println("Salario anual é: "+fn.CalucarSalAnual(900, 12));
                System.out.println("Média Salario anuel é : "+fn.CalcularMediaSalAnual(900, 12));
                System.out.println("Valor do 13º é: "+fn.Calcular13Sal(900, 12));
                System.out.println("Salario em uma decada é: "+fn.SomarSalDecada(900, 12));
         
            if(hm.ValidarCpf("123132132132222")){
                System.out.println("CPF verdadeiro");
            }else{
                System.out.println("CPF falso");
            }
         
         
            if(hm.ValidarSexo('M')){
                System.out.println("Sexo masculino");
            }else{
                System.out.println("sexo feminino");
            }
         
         
            if(hm.ValidarMaiorIdade(17)){
                System.out.println("de maior");
            }else{
                System.out.println("de menor");
            }
            
            
            if(hm.Aposentar(62)){
                System.out.println("se aposenta");
            }else{
                System.out.println("nao se aposenta");
            }
    }
}
