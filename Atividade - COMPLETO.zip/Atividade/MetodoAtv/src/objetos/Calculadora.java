
package objetos;

public class Calculadora {
    
    public int valor1;
    public int valor2;
    
     public double Somar(double valor1, double valor2){
        return valor1+valor2;
        
    }
    
    public double Subtrair(double valor1, double valor2){ 
        return valor1-valor2; 
    
    }    
            
    public static double Multiplicar(double valor1, double valor2){
        return valor1*valor2;
    
    }
    
    public static double Dividir(double valor1, double valor2){
        return valor1/valor2;
    
    }
    
}
