
package objetos;

public class Homem {
    public String nome;
    public String cpf;
    public char sexo;
    public int idade;
    
public boolean ValidarCpf(String cpf){
        if(cpf.length() == 14){
         return true;
        }else{
           return false;     
        }
}

public boolean ValidarSexo(char sexo){
         if(sexo == 'M'){
         return true;
        }else{
           return false;   
        }
        
}

public static boolean ValidarMaiorIdade(int idade){
        if(idade >=18){
         return true;
        }else{
           return false;   
        }

}

public static boolean Aposentar(int idade){
        if(idade >=62){
         return true;
        }else{
           return false;   
        }

}

}
