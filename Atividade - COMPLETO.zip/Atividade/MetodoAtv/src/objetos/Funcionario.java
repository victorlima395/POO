
package objetos;

public class Funcionario {
     public double valorSal;
    public int qtdMesesTrabalhado;


public double CalucarSalAnual(double valorSal, int qtdMesesTrabalho){
    return valorSal * qtdMesesTrabalho;

}

public double CalcularMediaSalAnual(double valorSal, int qtdMesesTrabalho){
    return (valorSal * qtdMesesTrabalho)/12;
    
}

public static double Calcular13Sal(double valorSal, int qtdMesesTrabalho){
     double sal13 = (valorSal * qtdMesesTrabalho)/12;
     return sal13;
         
}

public static double SomarSalDecada(double valorSal, int qtdMesesTrabalho){
     double salDecada = ((valorSal * qtdMesesTrabalho)*12)*10;
     return salDecada;
     
}     

    
}
