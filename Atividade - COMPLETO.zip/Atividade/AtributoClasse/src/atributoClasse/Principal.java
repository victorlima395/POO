package atributoClasse;

public class Principal {

    public static void main(String[] args) {

        //Sem a instância
        Carro.acelerador = true;
        Carro.direcao = true;
        Carro.freio = true;
        Carro.qtdRodas = "4";
        Carro.step = true;

        //Com a instância
        Carro carro2 = new Carro();
        carro2.acelerador = false;
        carro2.direcao = true;
        carro2.freio = false;
        carro2.qtdRodas = "4";
        carro2.step = true;

        Empresa empresa = new Empresa();
        //Sem a instância
        Empresa.CNPJ = "123.258.269.265/123";
        Empresa.nacionalidade = "Brasileira";
        Empresa.qtdFuncionarios = "150";
        Empresa.qtdSetores = "15";
        Empresa.tamanhoTotal = "245 m²";

        //Com a instância
        Empresa empresa2 = new Empresa();
        empresa2.CNPJ = "638.258.000.265/123";
        empresa2.nacionalidade = "Mexicana";
        empresa2.qtdFuncionarios = "300";
        empresa2.qtdSetores = "25";
        empresa2.tamanhoTotal = "400 m²";

        //Sem a instância
        Moto.acelerador = true;
        Moto.banco = true;
        Moto.embreagem = true;
        Moto.freio = true;
        Moto.qtdRodas = "2";
        
        //Com a istância
        Moto moto2 = new Moto();
        moto2.acelerador = false;
        moto2.banco = true;
        moto2.embreagem = false;
        moto2.freio = true;
        moto2.qtdRodas = "2";

        //Sem a instância
        PlanetaTerra.galaxia = "Via Lactea";
        PlanetaTerra.numeroSatelitesNaturais = "1";
        PlanetaTerra.oxigenio = true;
        PlanetaTerra.qtdContinentes = "5";
        PlanetaTerra.qtdPaises = "193";
        
        //Com a instância
        PlanetaTerra terra2 = new PlanetaTerra();
        terra2.galaxia = "Via Lactea";
        terra2.numeroSatelitesNaturais = "1";
        terra2.oxigenio = false;
        terra2.qtdContinentes = "5";
        terra2.qtdPaises = "193";
        
        System.out.println("Carro: \n");
        System.out.println("Possui Acelerador? " + Carro.acelerador);
        System.out.println("Possui Direção? : " + Carro.direcao);
        System.out.println("Possui Freios? " + Carro.freio);
        System.out.println("Quantidade de Rodas: " + Carro.qtdRodas);
        System.out.println("Possui Step: " + Carro.step + "\n____________________________________________________");
    
        System.out.println("Carro 2: \n");
        System.out.println("Possui Acelerador? " + carro2.acelerador);
        System.out.println("Possui Direção? : " + carro2.direcao);
        System.out.println("Possui Freios? " + carro2.freio);
        System.out.println("Quantidade de Rodas: " + carro2.qtdRodas);
        System.out.println("Possui Step: " + carro2.step + "\n____________________________________________________");
    
        System.out.println("Empresa: \n");
        System.out.println("CNPJ " + Empresa.CNPJ);
        System.out.println("Nascionalidade: " + Empresa.nacionalidade);
        System.out.println("Quantidade de Funcionários: " + Empresa.qtdFuncionarios);
        System.out.println("Quantidade de Setores: " + Empresa.qtdSetores);
        System.out.println("Tamanho Total: " + Empresa.tamanhoTotal + "\n____________________________________________________");
    
        System.out.println("Empresa 2: \n");
        System.out.println("CNPJ " + empresa2.CNPJ);
        System.out.println("Nascionalidade: " + empresa2.nacionalidade);
        System.out.println("Quantidade de Funcionários: " + empresa2.qtdFuncionarios);
        System.out.println("Quantidade de Setores: " + empresa2.qtdSetores);
        System.out.println("Tamanho Total: " + empresa2.tamanhoTotal + "\n____________________________________________________");
    
        System.out.println("Moto: \n");
        System.out.println("Possui Acelerador? " + Moto.acelerador);
        System.out.println("Possui Embreágem? " + Moto.embreagem);
        System.out.println("Possui Freios? " + Moto.freio);
        System.out.println("Quantidade de Rodas: " + Moto.qtdRodas);
        System.out.println("Possui banco? " + Moto.banco + "\n____________________________________________________");
    
        System.out.println("Moto 2: \n");
        System.out.println("Possui Acelerador? " + moto2.acelerador);
        System.out.println("Possui Embreágem? " + moto2.embreagem);
        System.out.println("Possui Freios? " + moto2.freio);
        System.out.println("Quantidade de Rodas: " + moto2.qtdRodas);
        System.out.println("Possui banco? " + moto2.banco + "\n____________________________________________________");
        
        System.out.println("Planeta: \n");
        System.out.println("Galáxia: " + PlanetaTerra.galaxia);
        System.out.println("Número de Satelites Nsturais: " + PlanetaTerra.numeroSatelitesNaturais);
        System.out.println("Quantidade de Continentes: " + PlanetaTerra.qtdContinentes);
        System.out.println("Quantidade de Países: " + PlanetaTerra.qtdPaises);
        System.out.println("Possui Oxigênio? " + PlanetaTerra.oxigenio + "\n____________________________________________________");
        
        System.out.println("Planeta 2: \n");
        System.out.println("Galáxia: " + terra2.galaxia);
        System.out.println("Número de Satelites Nsturais: " + terra2.numeroSatelitesNaturais);
        System.out.println("Quantidade de Continentes: " + terra2.qtdContinentes);
        System.out.println("Quantidade de Países: " + terra2.qtdPaises);
        System.out.println("Possui Oxigênio? " + terra2.oxigenio + "\n____________________________________________________");
        
        
    }

}
