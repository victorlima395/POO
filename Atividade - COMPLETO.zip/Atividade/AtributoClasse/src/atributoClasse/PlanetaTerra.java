
package atributoClasse;

public class PlanetaTerra {
    
    public static String galaxia;
    public static String numeroSatelitesNaturais;
    public static boolean oxigenio;
    public static String qtdContinentes;
    public static String qtdPaises;
    
    
}
