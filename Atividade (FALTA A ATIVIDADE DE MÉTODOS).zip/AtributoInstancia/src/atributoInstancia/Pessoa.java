
package atributoInstancia;

public class Pessoa {
    
    public String cpf;
    public String nome;
    public char sexo;
    public String dataNascimento;
    public String altura;
    
}
