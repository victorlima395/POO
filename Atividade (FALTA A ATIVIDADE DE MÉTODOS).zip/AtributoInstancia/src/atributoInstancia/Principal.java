
package atributoInstancia;

public class Principal {
    
    public static void main(String[] args) {
        
        Casa casa = new Casa();
        casa.energiaEletrica = true;
        casa.numero = "99";
        casa.garagem = false;
        casa.qtdComodos = "4";
        casa.tamanho = "5 X 20 ";
        
        Casa casa2 = new Casa();
        casa2.energiaEletrica = true;
        casa2.numero = "45";
        casa2.garagem = true;
        casa2.qtdComodos = "7";
        casa2.tamanho = "6 X 15 ";
        
        Pessoa pessoa = new Pessoa();
        pessoa.nome = "Victor Lima";
        pessoa.cpf = "078.626.863-81";
        pessoa.dataNascimento = "07/05/2000";
        pessoa.altura = "165cm";
        pessoa.sexo = 'M';
        
        Pessoa pessoa2 = new Pessoa();
        pessoa2.nome = "Alan Pery";
        pessoa2.cpf = "054,569.693-00";
        pessoa2.dataNascimento = "01/06/1998";
        pessoa2.altura = "172cm";
        pessoa2.sexo = 'M';
        
        Reuniao reuniao = new Reuniao();
        reuniao.assunto = "Finanças";
        reuniao.data = "13/08/2019";
        reuniao.horario = "19h";
        reuniao.local = "Faculdade Vale do Salgado";
        reuniao.qtdPessoas = "25";
        
        Reuniao reuniao2 = new Reuniao();
        reuniao2.assunto = "Andamento do projeto";
        reuniao2.data = "25/08/2019";
        reuniao2.horario = "14h";
        reuniao2.local = "Associação";
        reuniao2.qtdPessoas = "15";
        
        Smartphone smart = new Smartphone();
        smart.SO = "Android";
        smart.memRAM = "2GB";
        smart.processador = "Qualcomn Snapdragon 430";
        smart.tamanho = "5 Pol";
        smart.tipoTela = "IPS LCD";
        
        Smartphone smart2 = new Smartphone();
        smart2.SO = "IOS";
        smart2.memRAM = "3GB";
        smart2.processador = "A10 Bionic";
        smart2.tamanho = "4,5 Pol";
        smart2.tipoTela = "Retina";
        
        System.out.println("Casa: \n");
        System.out.println("Possui energia elétrica? " + casa.energiaEletrica);
        System.out.println("Numero da casa: " + casa.numero);
        System.out.println("Possui garagem? " + casa.garagem);
        System.out.println("Quantidade de comodos: " + casa.qtdComodos);
        System.out.println("Tamanho: " + casa.tamanho + "\n____________________________________________________");
        
        System.out.println("Casa 2: \n");
        System.out.println("Possui energia elétrica? " + casa2.energiaEletrica);
        System.out.println("Numero da casa: " + casa2.numero);
        System.out.println("Possui garagem? " + casa2.garagem);
        System.out.println("Quantidade de comodos: " + casa2.qtdComodos);
        System.out.println("Tamanho: " + casa2.tamanho + "\n____________________________________________________");
        
        System.out.println("Pessoa: \n");
        System.out.println("Nome: " + pessoa.nome);
        System.out.println("CPF: " + pessoa.cpf);
        System.out.println("Data de Nascimento: " + pessoa.dataNascimento);
        System.out.println("Altura: " + pessoa.altura);
        System.out.println("Sexo: " + pessoa.sexo + "\n____________________________________________________");
        
        System.out.println("Pessoa 2: \n");
        System.out.println("Nome: " + pessoa2.nome);
        System.out.println("CPF: " + pessoa2.cpf);
        System.out.println("Data de Nascimento: " + pessoa2.dataNascimento);
        System.out.println("Altura: " + pessoa2.altura);
        System.out.println("Sexo: " + pessoa2.sexo + "\n____________________________________________________");
        
        System.out.println("Reunião: \n");
        System.out.println("Assunto: " + reuniao.assunto);
        System.out.println("Data: " + reuniao.data);
        System.out.println("Horario: " + reuniao.horario);
        System.out.println("Local: " + reuniao.local);
        System.out.println("Quantidade de pessoas: " + reuniao.qtdPessoas + "\n____________________________________________________");
        
        System.out.println("Reunião 2: \n");
        System.out.println("Assunto: " + reuniao2.assunto);
        System.out.println("Data: " + reuniao2.data);
        System.out.println("Horario: " + reuniao2.horario);
        System.out.println("Local: " + reuniao2.local);
        System.out.println("Quantidade de pessoas: " + reuniao2.qtdPessoas + "\n____________________________________________________");
 
        System.out.println("Smartphone: \n");
        System.out.println("Sistema operacional: : " + smart.SO);
        System.out.println("Quantidade de memoria RAM: " + smart.memRAM);
        System.out.println("Processador: " + smart.processador);
        System.out.println("Tamanho da tela: " + smart.tamanho);
        System.out.println("Tecnologia da tela: " + smart.tipoTela + "\n____________________________________________________");
    
        System.out.println("Smartphone 2: \n");
        System.out.println("Sistema operacional: : " + smart2.SO);
        System.out.println("Quantidade de memoria RAM: " + smart2.memRAM);
        System.out.println("Processador: " + smart2.processador);
        System.out.println("Tamanho da tela: " + smart2.tamanho);
        System.out.println("Tecnologia da tela: " + smart2.tipoTela + "\n____________________________________________________");
        
    }
    
}
