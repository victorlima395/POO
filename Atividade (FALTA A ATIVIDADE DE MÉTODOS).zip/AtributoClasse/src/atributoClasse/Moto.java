package atributoClasse;

public class Moto {

    public static boolean acelerador;
    public static boolean embreagem;
    public static boolean freio;
    public static boolean banco;
    public static String qtdRodas;
}
