
package atributoClasse;

public class Carro {
    public static String qtdRodas;
    public static boolean acelerador;
    public static boolean direcao;
    public static boolean freio;
    public static boolean step;
    
}
