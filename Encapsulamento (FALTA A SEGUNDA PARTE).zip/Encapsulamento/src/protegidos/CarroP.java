
package protegidos;

public class CarroP {

    String placa;
    String renavam;
    String cavalosPotencia;
    String cor;
}
