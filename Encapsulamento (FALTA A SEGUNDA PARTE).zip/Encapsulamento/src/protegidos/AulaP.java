package protegidos;

public class AulaP {

    protected String disciplina;
    protected String professor;
    protected String sala;
    protected String horario;

}
