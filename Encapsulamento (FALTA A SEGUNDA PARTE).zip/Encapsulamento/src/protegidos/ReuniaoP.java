
package protegidos;

public class ReuniaoP {
    public String local;
    public String horario;
    public String assunto;
    public String qtdPessoas;
    
}
