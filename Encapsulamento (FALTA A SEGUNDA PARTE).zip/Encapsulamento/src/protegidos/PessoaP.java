
package protegidos;

public class PessoaP {
    public String CPF;
    public String nome;
    public String dtNasc;
    public String RG;
    
}
