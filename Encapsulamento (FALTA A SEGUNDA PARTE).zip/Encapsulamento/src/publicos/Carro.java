
package publicos;

public class Carro {
    public String placa;
    public String renavam;
    public String cavalosPotencia;
    public String cor;
    
}
