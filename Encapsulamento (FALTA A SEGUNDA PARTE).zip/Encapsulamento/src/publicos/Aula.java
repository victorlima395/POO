
package publicos;

public class Aula {
    public String disciplina;
    public String professor;
    public String sala;
    public String horario;
    
}
