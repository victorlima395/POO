package publicos;

public class Principal {

    public static void main(String[] args) {
        Pessoa p1 = new Pessoa();

        System.out.println("Atributos de Pessoa:\n");

        p1.nome = "Victor Lima";
        p1.CPF = "078.626.863-81";
        p1.RG = "2009030939-7";
        p1.dtNasc = "01/05/2000";

        System.out.println("Nome: " + p1.nome + "\nCPF: " + p1.CPF + "\nRG: "
                + p1.RG + "\nData de Nascimento: " + p1.dtNasc + "\n");

        Reuniao r1 = new Reuniao();
        System.out.println("Atributos de Reunião:\n");

        r1.assunto = "Prestação de Contas";
        r1.horario = "19h";
        r1.local = "Faculdade Vale do Salgado";
        r1.qtdPessoas = "15";

        System.out.println("Assunto: " + r1.assunto + "\nCHorário: " + r1.horario
                + "\nLocal: " + r1.local + "\nQuantidade de Pessoas: " + r1.qtdPessoas + "\n");

        Carro c1 = new Carro();
        System.out.println("Atributos de Carro:\n");

        c1.placa = "TGE 2525";
        c1.renavam = "12589314785156";
        c1.cavalosPotencia = "100";
        c1.cor = "Vermelho";

        System.out.println("Placa: " + c1.placa + "\nRenavam: " + c1.renavam
                + "\nCavalos de Potência: " + c1.cavalosPotencia + "\nCor: " + c1.cor + "\n");
        
        Aula a1 = new Aula();
        System.out.println("Atributos de Aula: ");
        a1.disciplina = "POO";
        a1.horario = "18h30";
        a1.professor = "Adriano";
        a1.sala = "2";
        
        System.out.println("Disciplina: " + a1.disciplina + "\nHorario: " + a1.horario
                + "\nProfessor: " + a1.professor + "\nSala: " + a1.sala + "\n");
               

    }

}
