
package publicos;

public class Pessoa {
    public String CPF;
    public String nome;
    public String dtNasc;
    public String RG;
    
}
