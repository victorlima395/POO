
package publicos;

public class Reuniao {
    public String local;
    public String horario;
    public String assunto;
    public String qtdPessoas;
    
}
